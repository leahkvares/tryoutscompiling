i686-w64-mingw32-gcc -c essfunc.c -o essfunc.o

i686-w64-mingw32-gcc -shared \
    -o essfunc.dll \
    -Wl,--out-implib=libessfunc.a \
    -Wl,--image-base=0x62500000 \
    -Wl,--disable-dynamicbase \
    essfunc.o

i686-w64-mingw32-gcc \
    vulnserver.c \
    -o vulnserver.exe \
    -Wl,--disable-dynamicbase \
    -lws2_32 \
    -lntdll \
    ./libessfunc.a